<?php
require 'config.php'; requiere();
$msg = '';
if (es_post()) {
  $ini = $_POST['periodo_inicio']; $fin = $_POST['periodo_fin'];
  if ($fin < $ini) $msg = aviso('La fecha final no puede ser anterior a la inicial.', false);
  else {
    $st = $pdo->prepare('SELECT i.nombre, i.unidad, COUNT(*) n, SUM(m.cantidad) total FROM mediciones m JOIN indicadores i USING(id_indicador)
      WHERE m.fecha BETWEEN ? AND ? GROUP BY i.id_indicador, i.nombre, i.unidad ORDER BY i.nombre');
    $st->execute([$ini, $fin]); $partes = [];
    foreach ($st->fetchAll() as $r) $partes[] = $r['nombre'] . ': ' . number_format($r['total'], 2) . ' ' . $r['unidad'] . ' en ' . $r['n'] . ' medición(es)';
    $resumen = $partes ? implode('. ', $partes) . '.' : 'Sin mediciones en el periodo.';
    $pdo->prepare('INSERT INTO reportes_globales (id_usuario, titulo, periodo_inicio, periodo_fin, resumen) VALUES (?,?,?,?,?)')
        ->execute([$_SESSION['u']['id'], trim($_POST['titulo']), $ini, $fin, $resumen]);
    $msg = aviso('Reporte generado con las mediciones del periodo.');
  }
}
$rows = $pdo->query('SELECT r.*, u.nombre usuario FROM reportes_globales r JOIN usuarios u USING(id_usuario) ORDER BY r.fecha_generacion DESC, r.id_reporte DESC')->fetchAll();
cabecera('Reportes globales'); echo $msg;
echo '<div class="panel"><form class="f" method="post">' . csrf() . '<label>Título<input name="titulo" maxlength="150" required></label>
<label>Periodo inicial<input type="date" name="periodo_inicio" required></label><label>Periodo final<input type="date" name="periodo_fin" required></label>
<button>Generar reporte</button></form></div><div class="panel"><table><tr><th>Título</th><th>Periodo</th><th>Resumen</th><th>Generó</th></tr>';
foreach ($rows as $r) echo '<tr><td>' . e($r['titulo']) . '</td><td>' . e($r['periodo_inicio']) . ' a ' . e($r['periodo_fin']) . '</td><td>' . e($r['resumen']) . '</td><td>' . e($r['usuario']) . '<br><small>' . e($r['fecha_generacion']) . '</small></td></tr>';
echo '</table></div>'; pie();
