<?php
require 'config.php'; requiere();
$msg = '';
if (es_post()) {
  try {
    $a = $_POST['accion'] ?? '';
    if ($a === 'indicador') {
      $pdo->prepare('INSERT INTO indicadores (nombre, unidad, descripcion) VALUES (?,?,?)')
          ->execute([trim($_POST['nombre']), trim($_POST['unidad']), trim($_POST['descripcion']) ?: null]);
      $msg = aviso('Indicador agregado.');
    } elseif ($a === 'estado') {
      $pdo->prepare('UPDATE indicadores SET estado = 1 - estado WHERE id_indicador = ?')->execute([(int)$_POST['id']]);
      $msg = aviso('Estado del indicador actualizado.');
    } elseif ($a === 'meta') {
      if ($_POST['fecha_fin'] < $_POST['fecha_inicio'] || $_POST['valor_objetivo'] < 0) $msg = aviso('Revisa las fechas y que el valor objetivo no sea negativo.', false);
      else {
        $pdo->prepare('INSERT INTO metas (id_indicador, nombre_meta, valor_objetivo, fecha_inicio, fecha_fin, estado) VALUES (?,?,?,?,?,?)')
            ->execute([(int)$_POST['id_indicador'], trim($_POST['nombre_meta']), $_POST['valor_objetivo'], $_POST['fecha_inicio'], $_POST['fecha_fin'], $_POST['estado']]);
        $msg = aviso('Meta agregada.');
      }
    }
  } catch (PDOException $ex) { $msg = aviso('No se guardó: el nombre del indicador ya existe o hay un dato inválido.', false); }
}
$inds = $pdo->query('SELECT * FROM indicadores ORDER BY nombre')->fetchAll();
$metas = $pdo->query('SELECT t.*, i.nombre, i.unidad FROM metas t JOIN indicadores i USING(id_indicador) ORDER BY t.fecha_fin DESC')->fetchAll();
cabecera('Indicadores y metas'); echo $msg;
echo '<h2>Indicadores</h2><div class="panel"><form class="f" method="post">' . csrf() . '<input type="hidden" name="accion" value="indicador">
<label>Nombre<input name="nombre" maxlength="100" required></label><label>Unidad (kWh, m3, kg)<input name="unidad" maxlength="20" required></label>
<label>Descripción<input name="descripcion"></label><button>Agregar indicador</button></form></div>
<div class="panel"><table><tr><th>Nombre</th><th>Unidad</th><th>Descripción</th><th>Estado</th><th></th></tr>';
foreach ($inds as $i) echo '<tr><td>' . e($i['nombre']) . '</td><td>' . e($i['unidad']) . '</td><td>' . e($i['descripcion']) . '</td><td>' . ($i['estado'] ? 'Activo' : 'Inactivo') .
  '</td><td><form method="post">' . csrf() . '<input type="hidden" name="accion" value="estado"><input type="hidden" name="id" value="' . $i['id_indicador'] . '"><button class="sec">' . ($i['estado'] ? 'Desactivar' : 'Activar') . '</button></form></td></tr>';
echo '</table></div><h2>Metas</h2><div class="panel"><form class="f" method="post">' . csrf() . '<input type="hidden" name="accion" value="meta">
<label>Indicador<select name="id_indicador">';
foreach ($inds as $i) if ($i['estado']) echo '<option value="' . $i['id_indicador'] . '">' . e($i['nombre']) . '</option>';
echo '</select></label><label>Nombre (empieza con Reducir o Aumentar)<input name="nombre_meta" maxlength="150" required></label>
<label>Valor objetivo<input type="number" name="valor_objetivo" min="0" step="0.01" required></label>
<label>Inicio<input type="date" name="fecha_inicio" required></label><label>Fin<input type="date" name="fecha_fin" required></label>
<label>Estado<select name="estado"><option>Activa</option><option>Cumplida</option><option>Vencida</option><option>Cancelada</option></select></label>
<button>Agregar meta</button></form></div><div class="panel"><table><tr><th>Meta</th><th>Indicador</th><th>Objetivo</th><th>Periodo</th><th>Estado</th></tr>';
foreach ($metas as $m) echo '<tr><td>' . e($m['nombre_meta']) . '</td><td>' . e($m['nombre']) . '</td><td>' . number_format($m['valor_objetivo'], 2) . ' ' . e($m['unidad']) . '</td><td>' . e($m['fecha_inicio']) . ' a ' . e($m['fecha_fin']) . '</td><td>' . e($m['estado']) . '</td></tr>';
echo '</table></div>'; pie();
