<?php
require 'config.php';
if (isset($_GET['salir'])) { $_SESSION = []; session_destroy(); header('Location: login.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $st = $pdo->prepare('SELECT id_usuario, nombre, contrasena FROM usuarios WHERE correo = ?');
  $st->execute([trim($_POST['correo'] ?? '')]);
  $u = $st->fetch();
  if ($u && password_verify($_POST['contrasena'] ?? '', $u['contrasena'])) {
    session_regenerate_id(true);
    $_SESSION['u'] = ['id' => $u['id_usuario'], 'nombre' => $u['nombre']];
    header('Location: index.php'); exit;
  }
  $error = 'Correo o contraseña incorrectos.';
}
cabecera('Iniciar sesión');
echo '<div class="login panel">' . ($error ? aviso($error, false) : '') .
'<form method="post"><label>Correo<input type="email" name="correo" required autofocus></label>
<label>Contraseña<input type="password" name="contrasena" required></label>
<button>Entrar</button></form></div>';
pie();
