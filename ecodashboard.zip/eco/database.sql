-- Dashboard Socioecológico - Equipo 9 - ecodashboard_db (MySQL / MariaDB)
CREATE DATABASE IF NOT EXISTS ecodashboard_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecodashboard_db;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS reportes_globales, metas, mediciones, indicadores, usuarios;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE usuarios (
  id_usuario     INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre         VARCHAR(100) NOT NULL,
  correo         VARCHAR(100) NOT NULL UNIQUE,
  contrasena     VARCHAR(255) NOT NULL COMMENT 'Guardar hash, nunca texto plano',
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE indicadores (
  id_indicador INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre       VARCHAR(100) NOT NULL UNIQUE,
  unidad       VARCHAR(20) NOT NULL,
  descripcion  TEXT DEFAULT NULL,
  estado       TINYINT(4) NOT NULL DEFAULT 1 CHECK (estado IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE mediciones (
  id_medicion    INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_indicador   INT(11) NOT NULL,
  id_usuario     INT(11) NOT NULL,
  fecha          DATE NOT NULL,
  cantidad       DECIMAL(10,2) NOT NULL CHECK (cantidad >= 0),
  observaciones  TEXT DEFAULT NULL,
  fecha_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_mediciones_indicadores FOREIGN KEY (id_indicador) REFERENCES indicadores (id_indicador) ON UPDATE CASCADE,
  CONSTRAINT fk_mediciones_usuarios    FOREIGN KEY (id_usuario)   REFERENCES usuarios (id_usuario) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE metas (
  id_meta        INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_indicador   INT(11) NOT NULL,
  nombre_meta    VARCHAR(150) NOT NULL,
  valor_objetivo DECIMAL(10,2) NOT NULL CHECK (valor_objetivo >= 0),
  fecha_inicio   DATE NOT NULL,
  fecha_fin      DATE NOT NULL,
  estado         VARCHAR(20) NOT NULL DEFAULT 'Activa' CHECK (estado IN ('Activa','Cumplida','Vencida','Cancelada')),
  CONSTRAINT fk_metas_indicadores FOREIGN KEY (id_indicador) REFERENCES indicadores (id_indicador) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE reportes_globales (
  id_reporte       INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_usuario       INT(11) NOT NULL,
  titulo           VARCHAR(150) NOT NULL,
  periodo_inicio   DATE NOT NULL,
  periodo_fin      DATE NOT NULL,
  resumen          TEXT DEFAULT NULL,
  fecha_generacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reportes_usuarios FOREIGN KEY (id_usuario) REFERENCES usuarios (id_usuario) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usuarios de prueba. Contraseña de los tres: eco2026 (cámbienla)
INSERT INTO usuarios (id_usuario, nombre, correo, contrasena) VALUES
(1, 'Ana Lopez',    'ana.lopez@escuela.edu.mx',    '$2b$10$b/JQDK4oS8nQvRIT9G1JgOL.52/tQ65idRBa1HOesOEcoYjXL9QRy'),
(2, 'Carlos Ruiz',  'carlos.ruiz@escuela.edu.mx',  '$2b$10$b/JQDK4oS8nQvRIT9G1JgOL.52/tQ65idRBa1HOesOEcoYjXL9QRy'),
(3, 'Maria Torres', 'maria.torres@escuela.edu.mx', '$2b$10$b/JQDK4oS8nQvRIT9G1JgOL.52/tQ65idRBa1HOesOEcoYjXL9QRy');

INSERT INTO indicadores (id_indicador, nombre, unidad, descripcion, estado) VALUES
(1, 'Consumo electrico',   'kWh', 'Consumo de energia electrica del plantel.', 1),
(2, 'Consumo de agua',     'm3',  'Consumo de agua del plantel.', 1),
(3, 'Material reciclado',  'kg',  'Peso de los materiales reciclados recolectados.', 1);

INSERT INTO mediciones (id_indicador, id_usuario, fecha, cantidad, observaciones) VALUES
(1, 1, '2026-10-01', 1250.50, 'Lectura ilustrativa de consumo electrico.'),
(2, 2, '2026-10-02',  320.00, 'Lectura ilustrativa de consumo de agua.'),
(3, 3, '2026-10-03',   85.75, 'Cantidad ilustrativa de material reciclado.');

INSERT INTO metas (id_indicador, nombre_meta, valor_objetivo, fecha_inicio, fecha_fin, estado) VALUES
(1, 'Reducir el consumo electrico',        1100.00, '2026-10-01', '2026-12-31', 'Activa'),
(2, 'Reducir el consumo de agua',           280.00, '2026-10-01', '2026-12-31', 'Activa'),
(3, 'Aumentar el reciclaje recolectado',    100.00, '2026-10-01', '2026-12-31', 'Activa');

INSERT INTO reportes_globales (id_usuario, titulo, periodo_inicio, periodo_fin, resumen) VALUES
(1, 'Reporte ambiental de octubre',      '2026-10-01', '2026-10-31', 'Reporte de ejemplo para revisar los indicadores ambientales.'),
(2, 'Reporte de consumo de recursos',    '2026-10-01', '2026-10-15', 'Resumen ilustrativo de consumo de agua y electricidad.'),
(3, 'Reporte de materiales reciclados',  '2026-10-01', '2026-10-31', 'Resumen ilustrativo de recoleccion de materiales reciclables.');
