<?php
require 'config.php'; requiere();
$msg = '';
if (es_post()) {
  $cant = $_POST['cantidad'] ?? '';
  if (!is_numeric($cant) || $cant < 0) $msg = aviso('La cantidad debe ser un número mayor o igual a 0.', false);
  else {
    $pdo->prepare('INSERT INTO mediciones (id_indicador, id_usuario, fecha, cantidad, observaciones) VALUES (?,?,?,?,?)')
        ->execute([(int)$_POST['id_indicador'], $_SESSION['u']['id'], $_POST['fecha'], $cant, trim($_POST['observaciones'] ?? '') ?: null]);
    $msg = aviso('Medición registrada.');
  }
}
$inds = $pdo->query('SELECT id_indicador, nombre, unidad FROM indicadores WHERE estado=1 ORDER BY nombre')->fetchAll();
$f = (int)($_GET['indicador'] ?? 0);
$st = $pdo->prepare('SELECT m.fecha, i.nombre, m.cantidad, i.unidad, m.observaciones, u.nombre usuario FROM mediciones m
  JOIN indicadores i USING(id_indicador) JOIN usuarios u USING(id_usuario) WHERE (? = 0 OR m.id_indicador = ?)
  ORDER BY m.fecha DESC, m.id_medicion DESC LIMIT 100');
$st->execute([$f, $f]); $rows = $st->fetchAll();
cabecera('Mediciones'); echo $msg;
echo '<div class="panel"><form class="f" method="post">' . csrf() . '<label>Indicador<select name="id_indicador" required>';
foreach ($inds as $i) echo '<option value="' . $i['id_indicador'] . '">' . e($i['nombre']) . ' (' . e($i['unidad']) . ')</option>';
echo '</select></label><label>Fecha<input type="date" name="fecha" value="' . date('Y-m-d') . '" required></label>
<label>Cantidad<input type="number" name="cantidad" min="0" step="0.01" required></label>
<label>Observaciones<input name="observaciones"></label><button>Registrar medición</button></form></div>
<form method="get" class="f" style="margin-bottom:12px"><label>Filtrar por indicador<select name="indicador"><option value="0">Todos</option>';
foreach ($inds as $i) echo '<option value="' . $i['id_indicador'] . '"' . ($f == $i['id_indicador'] ? ' selected' : '') . '>' . e($i['nombre']) . '</option>';
echo '</select></label><button class="sec">Filtrar</button></form><div class="panel"><table><tr><th>Fecha</th><th>Indicador</th><th>Cantidad</th><th>Observaciones</th><th>Registró</th></tr>';
foreach ($rows as $r) echo '<tr><td>' . e($r['fecha']) . '</td><td>' . e($r['nombre']) . '</td><td>' . number_format($r['cantidad'], 2) . ' ' . e($r['unidad']) . '</td><td>' . e($r['observaciones']) . '</td><td>' . e($r['usuario']) . '</td></tr>';
echo '</table></div>'; pie();
