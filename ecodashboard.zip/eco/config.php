<?php
// Conexión a MySQL de XAMPP. Ajusten puerto/usuario/contraseña si los suyos son distintos.
const DB_HOST = '127.0.0.1', DB_PORT = 3307, DB_NAME = 'ecodashboard_db', DB_USER = 'root', DB_PASS = '';
session_start();
try {
  $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
} catch (PDOException $ex) {
  exit('<p style="font:16px sans-serif;padding:24px">No se pudo conectar a MySQL (puerto ' . DB_PORT . '). Inicien MySQL en XAMPP e importen database.sql en phpMyAdmin.</p>');
}
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function requiere() { if (empty($_SESSION['u'])) { header('Location: login.php'); exit; } }
function csrf() { $_SESSION['t'] ??= bin2hex(random_bytes(16)); return '<input type="hidden" name="t" value="' . $_SESSION['t'] . '">'; }
function es_post() { return $_SERVER['REQUEST_METHOD'] === 'POST' && hash_equals($_SESSION['t'] ?? '', $_POST['t'] ?? ''); }
function aviso($m, $ok = true) { return '<p class="aviso ' . ($ok ? 'bien' : 'mal') . '" role="status">' . e($m) . '</p>'; }
function cabecera($titulo) {
  $act = basename($_SERVER['SCRIPT_NAME']);
  $menu = ['index.php' => 'Resumen', 'mediciones.php' => 'Mediciones', 'catalogo.php' => 'Indicadores y metas', 'reportes.php' => 'Reportes'];
  echo '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . e($titulo) . ' · Dashboard Socioecológico</title><link rel="stylesheet" href="style.css"></head><body>';
  if (!empty($_SESSION['u'])) {
    echo '<header><b>Dashboard Socioecológico</b><nav>';
    foreach ($menu as $f => $n) echo '<a href="' . $f . '"' . ($f === $act ? ' aria-current="page"' : '') . '>' . $n . '</a>';
    echo '</nav><span>' . e($_SESSION['u']['nombre']) . ' · <a href="login.php?salir=1">Cerrar sesión</a></span></header>';
  }
  echo '<main><h1>' . e($titulo) . '</h1>';
}
function pie() { echo '</main></body></html>'; }
