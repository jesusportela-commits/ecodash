<?php
require 'config.php'; requiere();
$n = $pdo->query("SELECT (SELECT COUNT(*) FROM indicadores WHERE estado=1) i, (SELECT COUNT(*) FROM metas WHERE estado='Activa') m,
  (SELECT COUNT(*) FROM mediciones) d, (SELECT COUNT(*) FROM reportes_globales) r")->fetch();
$metas = $pdo->query("SELECT t.nombre_meta, t.valor_objetivo, t.fecha_fin, i.nombre, i.unidad,
  (SELECT m.cantidad FROM mediciones m WHERE m.id_indicador=t.id_indicador AND m.fecha BETWEEN t.fecha_inicio AND t.fecha_fin
   ORDER BY m.fecha DESC, m.id_medicion DESC LIMIT 1) ultima
  FROM metas t JOIN indicadores i USING(id_indicador) WHERE t.estado='Activa' ORDER BY i.nombre")->fetchAll();
$ult = $pdo->query("SELECT m.fecha, i.nombre, m.cantidad, i.unidad, u.nombre usuario FROM mediciones m
  JOIN indicadores i USING(id_indicador) JOIN usuarios u USING(id_usuario) ORDER BY m.fecha DESC, m.id_medicion DESC LIMIT 5")->fetchAll();
cabecera('Resumen');
echo '<div class="panel conteo"><span><b>' . $n['i'] . '</b> indicadores activos</span><span><b>' . $n['m'] . '</b> metas activas</span><span><b>' . $n['d'] . '</b> mediciones</span><span><b>' . $n['r'] . '</b> reportes</span></div>';
echo '<h2>Avance de metas activas</h2><div class="panel">';
if (!$metas) echo '<p>No hay metas activas. Crea una en Indicadores y metas.</p>';
foreach ($metas as $r) {
  $obj = (float)$r['valor_objetivo']; $u = $r['ultima']; $reducir = stripos($r['nombre_meta'], 'reducir') === 0;
  if ($u === null) { $pct = 0; $txt = '<span>Sin mediciones en el periodo</span>'; }
  else {
    $u = (float)$u; $ok = $reducir ? $u <= $obj : $u >= $obj;
    $pct = $reducir ? ($u > 0 ? min(100, round($obj / $u * 100)) : 100) : ($obj > 0 ? min(100, round($u / $obj * 100)) : 100);
    $txt = $ok ? '<span class="si">Meta cumplida</span>' : '<span class="no">Faltan ' . number_format(abs($u - $obj), 2) . ' ' . e($r['unidad']) . '</span>';
  }
  echo '<div class="meta"><div>' . e($r['nombre_meta']) . '<small>' . e($r['nombre']) . ' · vence ' . e($r['fecha_fin']) . '</small></div>
  <div><b>' . ($u === null ? '—' : number_format($u, 2)) . '</b> / ' . number_format($obj, 2) . ' ' . e($r['unidad']) . '</div>
  <div class="bar" role="img" aria-label="' . $pct . '% de avance"><i style="width:' . $pct . '%"></i></div><div>' . $txt . '</div></div>';
}
echo '</div><h2>Últimas mediciones</h2><div class="panel"><table><tr><th>Fecha</th><th>Indicador</th><th>Cantidad</th><th>Registró</th></tr>';
foreach ($ult as $r) echo '<tr><td>' . e($r['fecha']) . '</td><td>' . e($r['nombre']) . '</td><td>' . number_format($r['cantidad'], 2) . ' ' . e($r['unidad']) . '</td><td>' . e($r['usuario']) . '</td></tr>';
echo '</table></div>'; pie();
